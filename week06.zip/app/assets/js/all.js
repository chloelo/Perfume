$(function() {
  console.log('hello');
});